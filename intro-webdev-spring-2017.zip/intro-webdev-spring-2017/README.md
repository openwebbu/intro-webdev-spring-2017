# Open Web Introduction to Web Development Workshop - Fall 2016

## Fall 2016 Updates
* Moved reset styles to bootstrap.css
* Changed length of lorem ipsum text